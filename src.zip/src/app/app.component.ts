import { Component, OnInit } from '@angular/core';
import { StudentService } from './student.service';
import { students } from './student/students';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'Student-Profiles';

  studentList : students[] = [];
  constructor(private _studentService: StudentService) {
  }

  ngOnInit(): void {
    this._studentService.getStudentInfo()
      .subscribe(data => this.studentList = data);
  }
}
