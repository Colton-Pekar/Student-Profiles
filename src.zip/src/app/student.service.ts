import { students } from './student/students';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/';

@Injectable({
  providedIn: 'root'
})

export class StudentService {
  private _url = "https://api.hatchways.io/assessment/students"
  constructor(private http: HttpClient){}

  getStudentInfo(): Observable<students[]>{
      return this.http.get<students[]>(this._url);
  }
}
