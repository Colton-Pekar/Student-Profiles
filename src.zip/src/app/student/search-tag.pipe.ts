import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name: "searchFilterTag"
})

export class SearchTagPipe implements PipeTransform{
    transform(value: any, args?:any):any{
        if (!value) return null;
        if (!args) return value;

        args = args.toLowerCase();
        return value.filter(function(item:any){
            return JSON.stringify(item.tags)
            .toLowerCase()
            .includes(args);
        });
    }
}