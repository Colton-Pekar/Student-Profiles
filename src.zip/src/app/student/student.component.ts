import { StudentService } from '../student.service';
import { Component, OnInit } from '@angular/core';
import { students } from './students';
import { SearchFilterPipe } from './search-filter.pipe';
import { SearchFilterLNPipe } from './search-filter-LN.pipe';
import { SearchTagPipe } from './search-tag.pipe';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  searchText: string = "";
  searchTag: string = "";
  addaTag: string[] = [];
  studentList : students[] = [];
  index:number = 0;

  constructor(private _studentService: StudentService) {
  }

  ngOnInit(): void {
    this._studentService.getStudentInfo()
      .subscribe((data:any) => {
        console.log('data', data) 
        this.studentList = data.students
        for (var i = 0; i<this.studentList.length; i++){
          for (var j=0; j<=this.studentList.length; j++){
            this.studentList[i].tags = []
            this.studentList[i].fullName = ""
          }
          let total : number = 0
            for (var j = 0; j<this.studentList[i].grades.length; j++){
              total = total + parseInt(this.studentList[i].grades[j])
            }
          this.studentList[i].average = total/8
          }
          for (var i = 0; i<this.studentList.length; i++){
          this.studentList[i].fullName = this.studentList[i].firstName.toUpperCase() + " " + this.studentList[i].lastName.toUpperCase()}
        })
  }     

  toggle(firstName:any) {
    for (var i = 0; i<this.studentList.length; i++){
    if (firstName == this.studentList[i].firstName)
    this.studentList[i].show = !this.studentList[i].show;
    // CHANGE THE NAME OF THE BUTTON.
    if(this.studentList[i].show)  
      this.studentList[i].buttonName = "Hide";
    else
      this.studentList[i].buttonName = "Show";
    }
  }

  addTag(firstName:any, index:any){
    for (var i = 0; i<this.studentList.length; i++){
      if (firstName == this.studentList[i].firstName)
        this.studentList[i].tags.push(this.addaTag[index])
    }
  }

  increment(){
    return this.index++;
  }
}
