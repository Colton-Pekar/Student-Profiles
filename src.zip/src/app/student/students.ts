export interface students{
    city: string,
    company: string,
    email: string,
    firstName: string,
    grades: [],
    id: string,
    lastName: string,
    pic: string,
    skill: string,
    average: Number,
    buttonName: string,
    show: boolean,
    tags: string[],
    fullName: string
}